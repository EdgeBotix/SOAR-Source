dimensions(8,2)

wall((0, 2), (8, 2))

wall((1, 1.5),(1.5, 1.5))

wall((2, 1.5),(2.5, 1.5))

wall((3, 1.5),(3.5, 1.5))

initialRobotLoc(1.0, 1.0)
